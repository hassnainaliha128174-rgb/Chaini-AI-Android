package com.chaini.ai

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : Activity() {
    private var rewardedAd: RewardedAd? = null
    private lateinit var web: WebView

    // Replace this with the final Vercel URL later.
    private val webUrl = "REPLACE_WITH_YOUR_VERCEL_URL"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        MobileAds.initialize(this) {}

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(AdsBridge(), "AndroidAds")
            webViewClient = WebViewClient()
        }

        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val banner = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = "ca-app-pub-3940256099942544/6300978111"
            loadAd(AdRequest.Builder().build())
        }

        root.addView(banner, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        if (webUrl.startsWith("http")) {
            web.loadUrl(webUrl)
        } else {
            Toast.makeText(
                this,
                "Set your Vercel URL in MainActivity.kt",
                Toast.LENGTH_LONG
            ).show()
        }

        loadRewardedAd()
    }

    private fun loadRewardedAd() {
        RewardedAd.load(
            this,
            "ca-app-pub-3940256099942544/5224354917",
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(
                    error: com.google.android.gms.ads.LoadAdError
                ) {
                    rewardedAd = null
                }
            }
        )
    }

    private fun showRewarded(requestId: String) {
        val ad = rewardedAd

        if (ad == null) {
            Toast.makeText(
                this,
                "Test rewarded ad is still loading. Try again.",
                Toast.LENGTH_SHORT
            ).show()
            loadRewardedAd()
            return
        }

        rewardedAd = null

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadRewardedAd()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                loadRewardedAd()
            }
        }

        ad.show(this) {
            web.post {
                web.evaluateJavascript(
                    "window.onChainiRewardedAdComplete(${jsString(requestId)})",
                    null
                )
            }
        }
    }

    private fun jsString(value: String): String {
        return "'" + value
            .replace("\\", "\\\\")
            .replace("'", "\'") + "'"
    }

    inner class AdsBridge {
        @JavascriptInterface
        fun showRewardedAd(requestId: String, reason: String?) {
            runOnUiThread {
                showRewarded(requestId)
            }
        }
    }
}
