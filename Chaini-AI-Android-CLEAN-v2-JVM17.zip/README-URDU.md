# Chaini AI Android — Clean AdMob Test

یہ صاف Android test project ہے۔

- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (GitHub Actions workflow سے)
- AdMob Test App ID
- Test Banner Ad
- Test Rewarded Ad
- WebView + JavaScript bridge

اہم: MainActivity.kt میں بعد میں صرف Vercel URL تبدیل کرنا ہوگا۔
