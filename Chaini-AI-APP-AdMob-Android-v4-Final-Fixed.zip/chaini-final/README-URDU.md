# Chaini AI Android — AdMob Test Build

یہ Android project Chaini AI web app کو WebView میں کھولتا ہے اور Google AdMob کے official test Banner/Rewarded ads استعمال کرتا ہے۔

- AdMob test App ID استعمال ہو رہی ہے۔
- Rewarded test ad JavaScript bridge کے ذریعے WebView سے چلتا ہے۔
- API keys اس project میں شامل نہیں ہیں۔
- Web app URL `MainActivity.kt` میں موجود ہے؛ production میں اسے اپنی Vercel URL سے بدلیں۔

## GitHub Actions
اگر project ZIP کو GitHub repository میں upload کیا جائے تو `.github/workflows/build-apk.yml` repository میں موجود کسی بھی `.zip` کو تلاش کرکے Android project extract کرے گا، Gradle 8.9 سے debug APK بنائے گا اور اسے artifact کے طور پر upload کرے گا۔
