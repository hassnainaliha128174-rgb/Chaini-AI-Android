# Chaini AI — AdMob Free Test Android Bridge v2

یہ ورژن WebView کے Chaini AI UI کو Android کے native Google Mobile Ads SDK کے **official test Rewarded Ad** کے ساتھ جوڑتا ہے۔ Google development میں test ad IDs استعمال کرنے کی سفارش کرتا ہے۔

## Test IDs
- Banner: `ca-app-pub-3940256099942544/6300978111`
- Rewarded: `ca-app-pub-3940256099942544/5224354917`
- Test App ID: `ca-app-pub-3940256099942544~3347511713`

## اہم
`MainActivity.kt` میں:
`https://chaini-ai-app-free-test-safe-v11.vercel.app`
کو اپنی Vercel URL سے replace کریں۔

Web UI میں rewarded-ad bridge شامل ہے: Generate unlock، Watermark remove اور Save کے test ad calls Android native rewarded ad دکھا سکتے ہیں۔ Reward صرف ad completion callback پر WebView کو ملتا ہے۔

Google کے مطابق development میں test ad units استعمال کریں؛ production/publishing سے پہلے انہیں اپنی AdMob IDs سے replace کرنا ہوگا۔
