package com.chaini.ai

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : Activity() {
    private var rewardedAd: RewardedAd? = null
    private lateinit var web: WebView
    private lateinit var topBanner: AdView
    private lateinit var bottomBanner: AdView

    private val webUrl = "https://chaini-ai-app-free-test-safe-v11.vercel.app"
    private val rewardedUnit = "ca-app-pub-3940256099942544/5224354917"
    private val bannerUnit = "ca-app-pub-3940256099942544/6300978111"

    // These IDs must be created with the same IDs in Play Console before real purchases work.
    private val productIds = listOf(
        "starter_10_credits",
        "creator_50_credits",
        "pro_100_credits",
        "chaini_pro_monthly"
    )
    private val productDetails = mutableMapOf<String, ProductDetails>()
    private lateinit var billingClient: BillingClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setupBilling()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        topBanner = makeBanner()
        root.addView(topBanner, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(AdsBridge(), "AndroidAds")
            addJavascriptInterface(BillingBridge(), "AndroidBilling")
            webViewClient = WebViewClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        bottomBanner = makeBanner()
        root.addView(bottomBanner, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        web.loadUrl(webUrl)
        loadRewardedAd()
        setHomeBanners(false)
    }

    private fun makeBanner(): AdView = AdView(this).apply {
        setAdSize(AdSize.BANNER)
        adUnitId = bannerUnit
        loadAd(AdRequest.Builder().build())
    }

    private fun setHomeBanners(home: Boolean) {
        val v = if (home) View.VISIBLE else View.GONE
        topBanner.visibility = v
        bottomBanner.visibility = v
    }

    private fun loadRewardedAd() {
        RewardedAd.load(this, rewardedUnit, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
            override fun onAdFailedToLoad(error: com.google.android.gms.ads.LoadAdError) { rewardedAd = null }
        })
    }

    private fun showRewarded(requestId: String) {
        val ad = rewardedAd
        if (ad == null) {
            web.post { web.evaluateJavascript("window.onChainiRewardedAdFailed(" + jsString(requestId) + "," + jsString("Rewarded ad ابھی load ہو رہا ہے۔ دوبارہ کوشش کریں۔") + ")", null) }
            loadRewardedAd()
            return
        }
        rewardedAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { loadRewardedAd() }
            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                web.post { web.evaluateJavascript("window.onChainiRewardedAdFailed(" + jsString(requestId) + "," + jsString(adError.message ?: "Rewarded ad failed.") + ")", null) }
                loadRewardedAd()
            }
        }
        ad.show(this) {
            web.post { web.evaluateJavascript("window.onChainiRewardedAdComplete(" + jsString(requestId) + ")", null) }
        }
    }

    private fun setupBilling() {
        billingClient = BillingClient.newBuilder(this)
            .setListener { billingResult, purchases -> handlePurchases(billingResult, purchases) }
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
            )
            .build()
        connectBilling()
    }

    private fun connectBilling() {
        if (billingClient.isReady) {
            queryProducts()
            return
        }
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProducts()
                else notifyBillingFailed("Google Play Billing unavailable: ${result.debugMessage}")
            }
            override fun onBillingServiceDisconnected() {
                // The next purchase attempt reconnects.
            }
        })
    }

    private fun queryProducts() {
        val list = productIds.map { id ->
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(id)
                .setProductType(if (id == "chaini_pro_monthly") BillingClient.ProductType.SUBS else BillingClient.ProductType.INAPP)
                .build()
        }
        billingClient.queryProductDetailsAsync(
            QueryProductDetailsParams.newBuilder().setProductList(list).build()
        ) { result, detailsResult ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                productDetails.clear()
                detailsResult.productDetailsList.forEach { productDetails[it.productId] = it }
                notifyBillingReady()
            } else {
                notifyBillingFailed("Products could not be loaded: ${result.debugMessage}")
            }
        }
    }

    private fun purchase(productId: String) {
        if (!billingClient.isReady) {
            connectBilling()
            notifyBillingFailed("Google Play Billing ابھی connect ہو رہا ہے۔ دوبارہ کوشش کریں۔")
            return
        }
        val pd = productDetails[productId]
        if (pd == null) {
            queryProducts()
            notifyBillingFailed("یہ paid item ابھی Google Play Console میں configured نہیں ہے۔")
            return
        }
        val params = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd)
        if (pd.productType == BillingClient.ProductType.SUBS) {
            val offerToken = pd.subscriptionOfferDetails?.firstOrNull()?.offerToken
            if (offerToken.isNullOrBlank()) {
                notifyBillingFailed("Subscription offer ابھی available نہیں ہے۔")
                return
            }
            params.setOfferToken(offerToken)
        } else {
            val offerToken = pd.oneTimePurchaseOfferDetailsList?.firstOrNull()?.offerToken
            if (!offerToken.isNullOrBlank()) params.setOfferToken(offerToken)
        }
        val flow = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(params.build()))
            .build()
        billingClient.launchBillingFlow(this, flow)
    }

    private fun handlePurchases(result: BillingResult, purchases: List<Purchase>?) {
        if (result.responseCode != BillingClient.BillingResponseCode.OK || purchases == null) {
            if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
                notifyBillingFailed(result.debugMessage.ifBlank { "Payment was not completed." })
            }
            return
        }
        purchases.forEach { purchase ->
            if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return@forEach
            val productId = purchase.products.firstOrNull() ?: return@forEach
            val isConsumable = productId != "chaini_pro_monthly"
            if (isConsumable) {
                billingClient.consumeAsync(
                    com.android.billingclient.api.ConsumeParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken)
                        .build()
                ) { consumeResult, _ ->
                    if (consumeResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        notifyPurchaseComplete(productId)
                    } else {
                        notifyBillingFailed("Payment completed, but credit confirmation failed. Please contact support.")
                    }
                }
            } else if (!purchase.isAcknowledged) {
                billingClient.acknowledgePurchase(
                    AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
                ) { ackResult ->
                    if (ackResult.responseCode == BillingClient.BillingResponseCode.OK) notifyPurchaseComplete(productId)
                    else notifyBillingFailed("Subscription confirmation failed. Please contact support.")
                }
            } else {
                notifyPurchaseComplete(productId)
            }
        }
    }

    private fun notifyBillingReady() {
        web.post { web.evaluateJavascript("window.onChainiBillingReady && window.onChainiBillingReady()", null) }
    }

    private fun notifyPurchaseComplete(productId: String) {
        web.post { web.evaluateJavascript("window.onChainiPurchaseComplete && window.onChainiPurchaseComplete(" + jsString(productId) + ")", null) }
    }

    private fun notifyBillingFailed(message: String) {
        web.post { web.evaluateJavascript("window.onChainiPurchaseFailed && window.onChainiPurchaseFailed(" + jsString(message) + ")", null) }
    }

    private fun jsString(value: String): String = "'" + value
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\n", "\\n")
        .replace("\r", "\\r") + "'"

    inner class AdsBridge {
        @JavascriptInterface
        fun showRewardedAd(requestId: String, reason: String?) = runOnUiThread { showRewarded(requestId) }

        @JavascriptInterface
        fun onScreenChanged(screen: String?) = runOnUiThread { setHomeBanners(screen == "home") }
    }

    inner class BillingBridge {
        @JavascriptInterface
        fun purchase(productId: String) = runOnUiThread { purchase(productId) }

        @JavascriptInterface
        fun refreshProducts() = runOnUiThread { connectBilling() }
    }
}
