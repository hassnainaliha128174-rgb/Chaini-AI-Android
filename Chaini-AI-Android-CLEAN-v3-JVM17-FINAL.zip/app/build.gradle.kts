plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chaini.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.chaini.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // Force the Kotlin compiler to use the same JDK target as Java.
    kotlin {
        jvmToolchain(17)
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.4.0")
}
