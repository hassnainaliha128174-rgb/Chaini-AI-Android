# Chaini AI APP — Clean Android AdMob Test

یہ فائل GitHub Actions کے لیے clean Android project ہے۔

اہم build fix:
- Java target = 17
- Kotlin JVM target = 17
- Kotlin JDK toolchain = 17
- Android Gradle Plugin = 8.7.3
- AdMob SDK = 25.4.0
- compileSdk = 35

AdMob کے لیے Google کے test App ID، banner test ID اور rewarded test ID استعمال کیے گئے ہیں۔

Vercel URL بعد میں `MainActivity.kt` میں تبدیل کرنا ہے۔
